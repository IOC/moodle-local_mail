angular.module('mm.addons.local_mail', ['mm.core'])
.constant('mmaLocalMailPriority', 500)
.constant('mmaLocalMailUnreadChangedEvent', 'mma.local_mail_unread_changed')
.config(["$stateProvider", "$mmSideMenuDelegateProvider", "$mmContentLinksDelegateProvider", "mmaLocalMailPriority", function($stateProvider, $mmSideMenuDelegateProvider, $mmContentLinksDelegateProvider, mmaLocalMailPriority) {
    $stateProvider
    .state('site.local_mail', {
        url: '/mail',
        params: {
        },
        views: {
            'site': {
                templateUrl: '$ADDONPATH$/templates/menu.html',
                controller: 'mmaLocalMailMenuCtrl'
            }
        }
    })
    .state('site.local_mail-index', {
        url: '/mail-index',
        params: {
            type: null,
            id: null,
            name: null
        },
        views: {
            'site': {
                templateUrl: '$ADDONPATH$/templates/index.html',
                controller: 'mmaLocalMailIndexCtrl'
            }
        }
    })
    .state('site.local_mail-message', {
        url: '/mail-message',
        params: {
            id: null,
            subject: null,
        },
        views: {
            'site': {
                templateUrl: '$ADDONPATH$/templates/message.html',
                controller: 'mmaLocalMailMessageCtrl'
            }
        }
    });
    $mmSideMenuDelegateProvider.registerNavHandler('mmaLocalMail', '$mmaLocalMailHandlers.sideMenuNav', mmaLocalMailPriority);
    $mmContentLinksDelegateProvider.registerLinkHandler('mmaLocalMail:message', '$mmaLocalMailHandlers.messageLinksHandler');
}])
.run(["$mmCronDelegate", function($mmCronDelegate) {
    $mmCronDelegate.register('mmaLocalMailMenu', '$mmaLocalMailHandlers.sideMenuNav');
}]);

angular.module('mm.addons.local_mail')
.controller('mmaLocalMailIndexCtrl', ["$scope", "$state", "$stateParams", "$mmSitesManager", "$mmSite", "$translate", "$mmaLocalMail", "$mmUtil", "$mmEvents", "mmaLocalMailUnreadChangedEvent", function($scope, $state, $stateParams, $mmSitesManager, $mmSite, $translate, $mmaLocalMail, $mmUtil, $mmEvents, mmaLocalMailUnreadChangedEvent) {
    $scope.messages = [];
    $scope.current = null;
    $scope.userid = $mmSite.getUserId();
    $scope.type = $stateParams.type;
    $scope.id = $stateParams.id;
    if ($stateParams.type == 'course' || $stateParams.type == 'label') {
        $scope.title = $stateParams.name;
    } else {
        $scope.title = $translate.instant('mma.local_mail.' + $stateParams.type);
    }
    function fetchIndex(refresh) {
        var offset = refresh ? 0 : $scope.messages.length;
        return $mmaLocalMail.getIndex($stateParams.type, $stateParams.id, offset, 20).then(function(index) {
            $scope.moreAvailable = index.messages.length > 0;
            if (refresh) {
                $scope.messages = index.messages;
            } else {
                $scope.messages = $scope.messages.concat(index.messages);
            }
        }, function(error) {
            $mmUtil.showErrorModal(error);
        });
    }
    var unreadChangedObserver = $mmEvents.on(mmaLocalMailUnreadChangedEvent, function(data) {
        if (data && $mmSitesManager.isCurrentSite(data.siteid)) {
            angular.forEach($scope.messages, function(message) {
                if (message.id == data.messageid) {
                    message.unread = data.unread;
                }
            });
        }
    });
    $scope.goToMessage = function(message) {
        $scope.current = message.id;
        $state.go('site.local_mail-message', {id: message.id, subject: message.subject});
    };
    $scope.loadMore = function() {
        fetchIndex(false).finally(function() {
            $scope.$broadcast('scroll.infiniteScrollComplete');
        });
    };
    $scope.refreshIndex = function() {
        $mmaLocalMail.invalidateIndexCache($stateParams.type, $stateParams.id).finally(function() {
            fetchIndex(true).finally(function() {
                $scope.$broadcast('scroll.refreshComplete');
            });
        });
    };
    $scope.$on('$destroy', function() {
        if (unreadChangedObserver) {
            unreadChangedObserver.off();
        }
    });
    fetchIndex(true).finally(function() {
        $scope.indexLoaded = true;
    });
}]);

angular.module('mm.addons.local_mail')
.controller('mmaLocalMailMenuCtrl', ["$scope", "$mmaLocalMail", "$mmUtil", "$mmSitesManager", "$mmEvents", "mmaLocalMailUnreadChangedEvent", function($scope, $mmaLocalMail, $mmUtil, $mmSitesManager, $mmEvents, mmaLocalMailUnreadChangedEvent) {
    function fetchMenu() {
        return $mmaLocalMail.getMenu().then(function(menu) {
            $scope.menu = menu;
        }, function(error) {
            $mmUtil.showErrorModal(error);
        });
    }
    $scope.refreshMenu = function() {
        $mmaLocalMail.invalidateMenuCache().finally(function() {
            fetchMenu().finally(function() {
                $scope.$broadcast('scroll.refreshComplete');
            });
        });
    };
    var unreadChangedObserver = $mmEvents.on(mmaLocalMailUnreadChangedEvent, function(data) {
        if (data && $mmSitesManager.isCurrentSite(data.siteid)) {
            fetchMenu();
        }
    });
    $scope.$on('$destroy', function() {
        if (unreadChangedObserver) {
            unreadChangedObserver.off();
        }
    });
    fetchMenu().finally(function() {
        $scope.menuLoaded = true;
    });
}]);

angular.module('mm.addons.local_mail')
.controller('mmaLocalMailMessageCtrl', ["$scope", "$stateParams", "$mmSite", "$mmUtil", "$ionicHistory", "$mmaLocalMail", function($scope, $stateParams, $mmSite, $mmUtil, $ionicHistory, $mmaLocalMail) {
    $scope.title = $stateParams.title;
    $scope.userid = $mmSite.getUserId();
    $scope.message = null;
    function fetchMessage() {
        return $mmaLocalMail.getMessage($stateParams.id).then(function(message) {
            $scope.message = message;
        }, function(error) {
            $mmUtil.showErrorModal(error);
        });
    }
    $scope.refreshMessage = function() {
        $mmaLocalMail.invalidateMessageCache($stateParams.id).finally(function() {
            fetchMessage().finally(function() {
                $scope.$broadcast('scroll.refreshComplete');
            });
        });
    };
    $scope.recipients = function(type) {
        var result = [];
        angular.forEach($scope.message.recipients, function(recipient) {
            if (recipient.type == type) {
                result.push(recipient);
            }
        });
        return result;
    };
    $scope.markAsUnread = function() {
        $mmaLocalMail.setUnread($scope.message.id, true).finally(function() {
            $ionicHistory.goBack();
        });
    };
    fetchMessage().then(function() {
        if ($scope.message.unread) {
            $mmaLocalMail.setUnread($scope.message.id, false);
            $scope.message.unread = false;
        }
    });
}]);

angular.module('mm.addons.local_mail')
.factory('$mmaLocalMailHandlers', ["$log", "$mmaLocalMail", "$mmSitesManager", "$mmEvents", "$mmContentLinkHandlerFactory", "$mmContentLinksHelper", "mmaLocalMailUnreadChangedEvent", function($log, $mmaLocalMail, $mmSitesManager, $mmEvents, $mmContentLinkHandlerFactory,
        $mmContentLinksHelper, mmaLocalMailUnreadChangedEvent) {
    $log = $log.getInstance('$mmaMessagesHandlers');
    var self = {};
    self.sideMenuNav = function() {
        var self = {};
        self.isEnabled = function() {
            return $mmaLocalMail.isPluginEnabled();
        };
        self.getController = function() {
            return function($scope) {
                $scope.icon = 'ion-email';
                $scope.title = 'mma.local_mail.mail';
                $scope.state = 'site.local_mail';
                $scope.class = 'mma.local_mail-handler';
                unreadChangedObserver = $mmEvents.on(mmaLocalMailUnreadChangedEvent, function(data) {
                    if (data && $mmSitesManager.isCurrentSite(data.siteid)) {
                        updateBadge();
                    }
                });
                function updateBadge() {
                    $mmaLocalMail.getMenu().then(function(info) {
                        $scope.badge = info.unread;
                    });
                }
                updateBadge();
            };
        };
        self.execute = function(siteId) {
            if ($mmSitesManager.isCurrentSite(siteId) && $mmaLocalMail.isPluginEnabled()) {
                $mmaLocalMail.invalidateMenuCache().finally(function() {
                    $mmEvents.trigger(mmaLocalMailUnreadChangedEvent, {
                        siteid: siteId
                    });
                });
            }
        };
        self.getInterval = function() {
            return 10000; 
        };
        self.isSync = function() {
            return true;
        };
        self.usesNetwork = function() {
            return true;
        };
        return self;
    };
    self.messageLinksHandler = $mmContentLinkHandlerFactory.createChild(
            /\/local\/mail\/view\.php.*([\&\?]m=\d+)/, '$mmSideMenuDelegate_mmaLocalMail');
    self.messageLinksHandler.isEnabled = function(siteId, url, params, courseId) {
        return $mmaLocalMail.isPluginEnabled(siteId);
    };
    self.messageLinksHandler.getActions = function(siteIds, url, params, courseId) {
        return [{
            action: function(siteId) {
                var stateParams = {
                    id: parseInt(params.m, 10),
                    subject: '',
                };
                $mmContentLinksHelper.goInSite('site.local_mail-message', stateParams, siteId);
            }
        }];
    };
    return self;
}]);

angular.module('mm.addons.local_mail')
.factory('$mmaLocalMail', ["$mmSite", "$mmSitesManager", "$mmEvents", "$log", "$q", "mmaLocalMailUnreadChangedEvent", function($mmSite, $mmSitesManager, $mmEvents, $log, $q, mmaLocalMailUnreadChangedEvent) {
    $log = $log.getInstance('$mmaLocalMail');
    var self = {};
    self.isPluginEnabled = function(siteId) {
        siteId = siteId || $mmSite.getId();
        return $mmSitesManager.getSite(siteId).then(function(site) {
            return site.wsAvailable('local_mail_get_unread_count') ;
        });
    };
    self._getCacheKeyForMenu = function() {
        return 'mmaLocalMail:menuInfo';
    };
    self._getCacheKeyForIndex = function(type, itemId, offset, limit) {
        var key = 'mmaLocalMail:index:';
        if (typeof type !== 'undefined') {
            key += type + ':';
        }
        if (type == 'course' || type == 'label') {
            key += itemId + ':';
        }
        if (typeof offset !== 'undefined' && typeof limit !== 'undefined') {
            key += offset + ':' + limit;
        }
        return key;
    };
    self._getCacheKeyForMessage = function(id) {
        return 'mmaLocalMail:message' + id;
    };
    self.invalidateMenuCache = function() {
        return $mmSite.invalidateWsCacheForKey(self._getCacheKeyForMenu());
    };
    self.invalidateIndexCache = function(type, itemId) {
        return $mmSite.invalidateWsCacheForKeyStartingWith(self._getCacheKeyForIndex(type, itemId));
    };
    self.invalidateMessageCache = function(id) {
        return $mmSite.invalidateWsCacheForKey(self._getCacheKeyForMessage(id));
    };
    self.getUnreadCount = function() {
        var presets = {
            getFromCache: 0,
            emergencyCache: 0,
            saveToCache: 0,
            typeExpected: 'number'
        };
        return $mmSite.read('local_mail_get_unread_count', {}, presets);
    };
    self.getMenu = function() {
        var presets = {
            cacheKey: self._getCacheKeyForMenu()
        };
        return $mmSite.read('local_mail_get_menu', {}, presets);
    };
    self.getIndex = function(type, itemId, offset, limit) {
        if (type !== 'course' && type !== 'label') {
            itemId = 0;
        }
        var presets = {
            cacheKey: self._getCacheKeyForIndex(type, itemId, offset, limit)
        };
        var params = {
            type: type,
            itemid: itemId,
            offset: offset,
            limit: limit,
        };
        return $mmSite.read('local_mail_get_index', params, presets);
    };
    self.getMessage = function(id) {
        var presets = {
            cacheKey: self._getCacheKeyForMessage(id)
        };
        return $mmSite.read('local_mail_get_message', {id: id}, presets);
    };
    self.setUnread = function(id, unread) {
        var params = {id: id, unread: unread ? '1' : '0'};
        var presets = {responseExpected: false};
        return $mmSite.write('local_mail_set_unread', params, presets).then(function() {
            var promises = [
                self.invalidateMessageCache(id),
                self.invalidateIndexCache(),
                self.invalidateMenuCache(),
            ];
            $q.all(promises).finally(function() {
                $mmEvents.trigger(mmaLocalMailUnreadChangedEvent, {
                    siteid: $mmSite.getId(),
                    messageid: id,
                    unread: unread,
                });
            });
        });
    };
    return self;
}]);
